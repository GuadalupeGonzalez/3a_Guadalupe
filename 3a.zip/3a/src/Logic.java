/*
 * Class Logic
 * @author Guadalupe
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */



public class Logic {

    //private String dataX;
    //private String dataY;
    //private String dataXk;
    //private String arrDataX;
    //private String arrDataY;
    //public String arrDataXk;
    //public double thisXk;

    private String data;
    private String[] arrData;
    private String[] estimacion;
    private int n;

   
    /**
     * Default constructor
     */
    public Logic() {
    }

    /**
     * @return
     */
    public void logic3a() {

        Input myInput = new Input();
        Output myOut = new Output();
        
		Data myData = new Data();
		EstimacionCorLineal myEsCoLi = new EstimacionCorLineal();

        data = myInput.readData("C:\\Users\\Hola\\OneDrive\\Documentos\\text1_lupe.txt");

		arrData = myData.saveData(data);
        n = arrData.length;
        System.out.println("");
        System.out.println("n : " + n);

        estimacion = myEsCoLi.Estimacion(arrData, n);

        System.out.println("");

        myOut.writeData("C:\\Users\\Hola\\OneDrive\\Documentos\\resultado1_lupe.txt", "SumX = " + estimacion[0] + "\nSumY = " + estimacion[1] + "\nSumXX = " + estimacion[2] + "\nSumXY = " + estimacion[3] + "\nSumYY = " + estimacion[4] + "\nAvgX = " + estimacion[5] + "\nAvgY = " + estimacion[6] + "\nB1 = " + estimacion[7] + "\nB0 = " + estimacion[8] + "\nRxy = " + estimacion[9] + "\nYK = " + estimacion[10] + "\nR = " + estimacion[11]);
    }

}